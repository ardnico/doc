# Agent Operating Rules for V-Model Development

This repository uses GitHub Copilot agents and skills as assistants for a controlled V-model / waterfall-style development process.

## Primary target

The primary development target is C, Linux device drivers, Linux kernel-related source, BSP-related code, and low-level platform software.
Java, Python, Rust, and application-layer code may also be handled under the same process, but language-specific details must not override the V-model rules.

## Absolute priorities

1. Follow the defined V-model process in `.github/process/phase-map.yml`.
2. Treat approved previous-phase artifacts as authoritative inputs.
3. Do not treat drafts, chat history, personal memory, or inferred intent as authoritative.
4. Do not invent requirements, design decisions, interfaces, environmental conditions, middleware conditions, or test expectations.
5. If required information is missing, record it as a TBD/blocker and stop progression.
6. Every output must preserve traceability to source IDs.
7. Repository documents override Redmine extracts, personal memory, and chat history unless a human review record says otherwise.
8. For design and implementation decisions, prefer official documentation that matches the target version.
9. If official documentation and existing project artifacts conflict, flag the conflict. Do not silently choose one.
10. Agents may recommend pass/fail, but humans approve phase completion through review records.

## Source priority

1. Approved review records and approved repository artifacts
2. `.github/process/artifact-registry.yml`
3. `.github/process/phase-map.yml`
4. Traceability matrix
5. Redmine ticket extracts imported into the repository
6. Current issue or pull request text
7. User prompt
8. Personal memory under the user's home directory
9. Agent assumptions

Lower-priority sources must not override higher-priority sources.

## Required behavior before work

Before generating or modifying artifacts, identify:

- Current phase
- Required input artifacts
- Available input artifacts
- Missing mandatory artifacts
- Target language/platform
- Target version information
- Required official documentation
- Related Redmine tickets, if any
- Traceability IDs to be preserved

If mandatory inputs are missing, stop and output a blocker list.

## Version-aware official documentation rule

For C/Linux driver/kernel work, confirm and record at least:

- Linux kernel version
- target architecture/platform
- toolchain/compiler version when relevant
- BSP/Yocto/WRLinux version when relevant
- middleware version when relevant
- device specification version when relevant

When referring to official documentation, record:

- document title
- publisher/source
- version
- URL or repository path
- section/page/anchor if available
- date accessed if web-based
- applicability to the target version

Do not cite generic latest documentation when the project targets an older version.

## Prohibited actions

- Do not create new requirements during design or implementation.
- Do not change public interfaces without updating design documents and traceability.
- Do not remove or weaken tests to make implementation pass.
- Do not treat TODO comments as completed work.
- Do not rely on personal memory as authoritative project information.
- Do not proceed when mandatory phase inputs are missing.
- Do not mix unsupported versions of official documentation with target-version artifacts.
- Do not convert PDF/Word/Excel specifications to Markdown and treat the result as approved without human review.
- Do not treat Redmine ticket text as approved specification unless the artifact registry or review record marks it as approved.

## Approval model

Phase completion is approved through review records, not by agent output alone.
Agents must generate review findings and recommendations, but the final approval status must be recorded by humans using `.github/templates/design-review-record-template.md` or equivalent project review record.

## Intake routing

All user requests should first pass through the intake-router behavior unless the request is a simple explanation that does not create, modify, approve, or review project artifacts.

The intake-router must:

- classify the request;
- identify the current V-model phase;
- check mandatory upstream inputs;
- select the proper target agent and skills;
- ask blocking questions when required information is missing;
- stop phase-skipping requests unless a change-control path is used.

## Linux driver / kernel work

For Linux driver or kernel-related work, require the Linux-driver-specific design and review checks when the task touches:

- driver lifecycle;
- probe/remove;
- IRQ/MSI/MSI-X;
- DMA;
- MMIO/register access;
- locking/concurrency;
- sysfs/debugfs/ioctl/user ABI;
- RAS/logging/diagnostics;
- suspend/resume;
- kernel API version compatibility.

The target Linux kernel version and version-matched official references are mandatory for design and implementation work.

