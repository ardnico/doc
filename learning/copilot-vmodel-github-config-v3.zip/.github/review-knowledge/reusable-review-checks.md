# Reusable Review Checks

This file stores generic review findings promoted from human design/code reviews.

Do not add project-specific one-off comments here. Add only reusable checks that can improve future AI-assisted reviews.

## Format

```markdown
## CHK-0001: Short title

- Category: requirements | basic-design | detailed-design | implementation | test | traceability | environment | safety | security
- Applies to:
- Check:
- Why it matters:
- Example failure:
- Suggested fix:
- Source review: DR-xxxx or PR link
```

## Checks

_Add checks here after human approval._
