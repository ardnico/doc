# V-model Copilot Configuration

This directory defines Copilot instructions, agents, skills, templates, and process metadata for controlled V-model development.

## Scope

Primary scope:

- C
- Linux drivers
- Linux kernel-related source
- BSP/platform code

Secondary scope:

- Java
- Python
- Rust
- application-layer tools

## Process summary

1. Import or create input artifacts.
2. Convert PDF/Word/Excel/Redmine inputs to Markdown when needed.
3. Index artifacts and assign IDs.
4. Confirm required inputs for the current phase.
5. Use version-matched official documentation for design/implementation decisions.
6. Generate or review phase output.
7. Run gate review.
8. Human reviewers record approval status.
9. Update traceability.
10. Use change control for late changes.

## Important files

- `copilot-instructions.md`: repository-wide rules
- `../AGENTS.md`: agent operating rules
- `process/phase-map.yml`: phase input/output mapping
- `process/approval-policy.yml`: approval model
- `process/change-control.yml`: late-change rules
- `process/document-conversion.yml`: conversion policy
- `process/redmine-input.yml`: Redmine input policy
- `process/test-environment-policy.yml`: CI/manual/real-target test policy
- `skills/`: task-specific procedures
- `templates/`: artifact templates

## Hard rule

Agents assist. Review records approve.

## v3 additions

This version adds an intake-router agent. Use it as the front door for user questions and work requests. It classifies the request, checks required inputs, selects the proper agent/skills, and asks blocking questions when information is missing.

It also adds Linux driver/kernel-specific design and review skills. Use these for driver lifecycle, IRQ, DMA, MMIO, locking, ABI, diagnostics, RAS, and kernel-version compatibility work.

Key files:

- `.github/agents/intake-router.agent.md`
- `.github/process/intake-routing.yml`
- `.github/skills/intake-routing/SKILL.md`
- `.github/skills/linux-driver-design/SKILL.md`
- `.github/skills/linux-driver-review/SKILL.md`
- `.github/process/checklists/linux-driver-design-gate.md`
- `.github/templates/intake-result-template.md`

