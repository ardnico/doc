---
applyTo: "**/*"
---

# V-model process instructions

Use this instruction whenever work touches requirements, design, implementation, tests, review, or traceability.

## Required behavior

- Identify the current phase before producing output.
- Identify the previous-phase approved input.
- Identify whether the requested work is allowed in the current phase.
- Identify all source IDs used as input.
- Do not generate next-phase outputs from unapproved drafts unless clearly labeled as draft.
- If information is missing, produce a blocking input gap list rather than filling gaps with assumptions.

## Traceability requirement

Every generated item must include one or more source IDs.

Use these prefixes by default:

- `REQ-` for requirements
- `BD-` for basic design items
- `DD-` for detailed design items
- `IMPL-` for implementation items
- `UT-` for unit test items
- `IT-` for integration test items
- `ST-` for system test items
- `ENV-` for environment constraints
- `MID-` for middleware assumptions
- `MAN-` for manual / user documentation references
- `RISK-` for risks
- `TBD-` for unresolved items
- `DR-` for design review comments
- `CHK-` for reusable checklist items

## Phase-gate output format

For phase gate review, use:

```markdown
# Phase Gate Review

- Phase:
- Judgment: PASS / FAIL / CONDITIONAL PASS
- Reviewed artifact:
- Authoritative inputs:
- Missing mandatory inputs:

## Blocking issues

## Non-blocking issues

## Traceability gaps

## Test gaps

## Reusable checklist candidates

## Required fixes before next phase
```
