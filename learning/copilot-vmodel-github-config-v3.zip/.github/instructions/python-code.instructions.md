# Python Code Instructions

- Preserve V-model traceability.
- Record Python version and dependency versions.
- Prefer type hints for public interfaces.
- Keep side effects explicit.
- Add tests for behavior, error paths, and boundary cases.
- Do not use runtime behavior that conflicts with approved design.
