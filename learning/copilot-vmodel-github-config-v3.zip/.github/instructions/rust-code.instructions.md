---
applyTo: "**/*.rs"
---

# Rust implementation instructions

When editing Rust code:

- Link each change to an approved `DD-` item and `REQ-` item.
- Do not introduce behavior not described by detailed design.
- Prefer explicit error types and propagation over panic in production paths.
- Keep ownership, lifetime, concurrency, and unsafe assumptions documented.
- Avoid `unsafe` unless the detailed design explicitly justifies it.
- Update or propose corresponding unit tests and traceability entries.
