# C / Linux Kernel Code Instructions

- Preserve V-model traceability.
- Follow approved detailed design and coding standards.
- Check target Linux kernel version before using kernel APIs.
- For driver/kernel code, explicitly consider context: process, atomic, interrupt, threaded IRQ, workqueue, timer, and module init/exit.
- Check locking, lifetime, ownership, memory allocation context, DMA constraints, error paths, and cleanup paths.
- Do not sleep in atomic context.
- Do not use kernel APIs based on documentation for the wrong kernel version.
- Do not add behavior not present in approved design.
