# Java Code Instructions

- Preserve V-model traceability.
- Record Java version, build tool, and dependency versions.
- Keep public interfaces aligned with approved design.
- Add tests for normal, boundary, and error cases.
- Do not introduce framework behavior or dependencies not approved by design.
