# Redmine Ticket Import

## Ticket metadata

- Redmine Ticket ID:
- Title:
- Status:
- Tracker:
- Priority:
- Author:
- Assignee:
- Created at:
- Updated at:
- Target version:
- Source URL:

## Description

## Comments summary

## Attachments

| Attachment | Required input? | Notes |
|---|---|---|

## Classified items

| Item ID | Classification | Source location | Summary | Traceability target |
|---|---|---|---|---|

Classifications: requirement / constraint / issue / decision / discussion / TBD / reference.
