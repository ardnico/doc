# Intake Result

## Request summary

-

## Classification

| Item | Value |
|---|---|
| Request class | |
| Current phase | |
| Target agent | |
| Skills | |
| Proceed / Stop | |

## Inputs

### Required inputs

| Input | Required | Available | Status | Notes |
|---|---:|---:|---|---|
| | yes | no | missing | |

### Source artifacts

| Artifact ID | Name | Status | Version | Source |
|---|---|---|---|---|
| | | | | |

### Redmine inputs

| Ticket | Status | Imported | Reviewed | Notes |
|---|---|---:|---:|---|
| | | no | no | |

### Official references

| Topic | Required version | Reference | Status |
|---|---|---|---|
| | | | missing |

## Blocking questions

1.

## Non-blocking assumptions

- ASSUMP-0001:

## Next action

-
