# Requirements Specification

## Document control

- Artifact ID:
- Status: draft / approved / obsolete
- Owner:
- Reviewers:
- Approval date:

## Source inputs

| Source ID | Source | Summary |
|---|---|---|

## Requirements

| REQ ID | Type | Requirement | Rationale | Acceptance criteria | Source ID | Status |
|---|---|---|---|---|---|---|

## Non-functional requirements

| REQ ID | Category | Requirement | Measurement / acceptance criteria | Source ID | Status |
|---|---|---|---|---|---|

## Constraints

| ID | Constraint | Source | Impact |
|---|---|---|---|

## Assumptions

| ID | Assumption | Validation method | Blocking? |
|---|---|---|---|

## TBDs

| TBD ID | Item | Owner | Blocking? | Due |
|---|---|---|---|---|

## Initial system test candidates

| ST ID | Related REQ ID | Test objective | Notes |
|---|---|---|---|
