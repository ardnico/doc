# Official Reference Record

## Reference metadata

- Reference ID: REF-
- Title:
- Publisher/source:
- URL or repository path:
- Version:
- Target project version:
- Section/page/anchor:
- Accessed date:

## Applicability

- Applicable: yes / partial / no / unknown
- Reason:

## Used for

| Artifact ID | Topic | How it supports the artifact |
|---|---|---|

## Conflicts or notes
