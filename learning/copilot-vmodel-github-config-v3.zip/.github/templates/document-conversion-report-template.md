# Document Conversion Report

## Source document

- Source ID:
- Original filename/path:
- Original format: Markdown / PDF / Word / Excel / Redmine
- Version:
- Author/owner:
- Source date:
- Conversion date:

## Converted output

- Markdown path:
- Conversion status: complete / partial / failed

## Conversion issues

| Issue ID | Location | Description | Severity | Required action |
|---|---|---|---|---|

## Extracted candidate items

| Provisional ID | Type | Source location | Summary | Confidence | Human review required |
|---|---|---|---|---|---|

## Notes

Converted content is not approved until reviewed and registered.
