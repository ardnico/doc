# Design Specification

## Document control

- Artifact ID:
- Phase: basic-design / detailed-design
- Status: draft / approved / obsolete
- Owner:
- Reviewers:
- Approval date:

## Authoritative inputs

| Input artifact | Status | Relevant IDs |
|---|---|---|

## Design items

| Design ID | Source ID | Design content | Rationale | Impact | Status |
|---|---|---|---|---|---|

## Interfaces

| Interface ID | Related design ID | Direction | Data / protocol | Error behavior |
|---|---|---|---|---|

## Error handling / recovery

| ID | Condition | Expected behavior | Related design ID |
|---|---|---|---|

## Environment / middleware assumptions

| ID | Item | Required version / condition | Source | Blocking? |
|---|---|---|---|---|

## Test obligations

| Test ID | Level | Related design ID | Objective |
|---|---|---|---|

## TBDs

| TBD ID | Item | Owner | Blocking? | Due |
|---|---|---|---|---|
