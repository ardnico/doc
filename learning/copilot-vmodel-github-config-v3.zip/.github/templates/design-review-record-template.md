# Design Review Record

## Review control

- Review ID:
- Phase:
- Artifact:
- Review date:
- AI reviewer:
- Human reviewers:
- Judgment: PASS / FAIL / CONDITIONAL PASS

## Findings

| DR ID | Severity | Category | Related ID | Finding | Required action | Reusable checklist candidate? |
|---|---|---|---|---|---|---|

## Reusable checklist candidates

| Candidate CHK ID | Source DR ID | Proposed check | Rationale |
|---|---|---|---|

## Human approval

- Approver:
- Date:
- Conditions:
