# Change Request

## Metadata

- Change Request ID: CR-
- Origin: Redmine / Review / Test / Implementation / Official documentation update / Other
- Status: draft / in_review / approved / rejected / obsolete
- Owner:
- Reviewers:
- Date:

## Summary

## Reason

## Affected artifacts

| Artifact ID | Path | Current status | Impact |
|---|---|---|---|

## Affected traceability IDs

| ID | Type | Impact |
|---|---|---|

## Impact analysis

- Requirements impact:
- Design impact:
- Implementation impact:
- Test impact:
- Environment/middleware impact:
- Documentation/manual impact:

## Regression and retest scope

## Decision

- Approved / Rejected / Conditional approval
- Conditions:
- Approver:
- Date:
