# Traceability Matrix

## Summary

| Metric | Count |
|---|---:|
| Requirements | 0 |
| Basic design items | 0 |
| Detailed design items | 0 |
| Implementation items | 0 |
| Unit tests | 0 |
| Integration tests | 0 |
| System tests | 0 |
| Orphans | 0 |

## Matrix

| REQ ID | Basic Design ID | Detailed Design ID | Implementation ID | Unit Test ID | Integration Test ID | System Test ID | Status | Notes |
|---|---|---|---|---|---|---|---|---|

## Orphans

| Item ID | Type | Reason | Required action |
|---|---|---|---|

## Gaps

| Gap ID | Description | Blocking? | Owner | Due |
|---|---|---|---|---|
