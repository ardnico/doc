# Test Specification

## Document control

- Artifact ID:
- Test level: unit / integration / system
- Status: draft / approved / obsolete
- Owner:
- Reviewers:
- Approval date:

## Authoritative inputs

| Input artifact | Status | Relevant IDs |
|---|---|---|

## Test environment

| ENV ID | Required condition | Source | Blocking? |
|---|---|---|---|

## Test cases

| Test ID | Source ID | Purpose | Preconditions | Input | Procedure | Expected result | Pass/fail criteria |
|---|---|---|---|---|---|---|---|

## Required tools / stubs / mocks / simulators

| ID | Item | Purpose | Availability |
|---|---|---|---|

## Untestable items

| Source ID | Reason | Required action |
|---|---|---|
