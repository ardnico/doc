# Redmine Import Skill

## Purpose

Import Redmine ticket information as structured Markdown input while preserving ticket IDs and distinguishing approved facts from discussion.

## Inputs

- Redmine ticket export or copied ticket text
- Attachments list
- Project artifact registry
- Traceability matrix

## Outputs

- Redmine ticket import Markdown
- Classified ticket items
- Source references for traceability
- Missing attachment/input list

## Rules

- Preserve Redmine ticket ID and URL when available.
- Treat ticket text as input, not approved specification, unless a review record says otherwise.
- Classify description and comments separately.
- Do not let comments override approved artifacts.
- Flag stale tickets, conflicting statuses, and unresolved discussion.
- If attachments exist, determine whether they are mandatory input artifacts.

## Required checks

- [ ] Ticket metadata preserved
- [ ] Description classified
- [ ] Comments classified separately
- [ ] Attachments checked
- [ ] Related tickets recorded
- [ ] Traceability source links created
- [ ] Conflicts with approved artifacts reported
