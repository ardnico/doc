# Change Control Skill

## Purpose

Control late changes after phase approval and prevent unreviewed requirement/design/test changes from leaking into implementation.

## Inputs

- Change request or proposed change
- Affected artifacts
- Traceability matrix
- Review records
- Current phase

## Outputs

- Change request record
- Impact analysis
- Required phase rollback or exception approval
- Regression and retest scope

## Rules

- If a change affects approved requirements, require requirements-phase review or explicit exception approval.
- If a change affects approved design, require design review.
- If a change affects tests, update traceability and retest scope.
- Do not implement late changes directly.
- Do not hide scope changes as refactoring.

## Required checks

- [ ] Affected artifacts identified
- [ ] Affected traceability IDs identified
- [ ] Phase rollback need assessed
- [ ] Regression scope defined
- [ ] Human approval required
