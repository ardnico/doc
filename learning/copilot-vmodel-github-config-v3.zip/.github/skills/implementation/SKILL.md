# Implementation Skill

## Purpose

Implement code from approved detailed design while preserving traceability and testability.

## Inputs

- Approved detailed design
- Approved test design
- Coding standards
- Environment and middleware conditions
- Official version-matched documentation
- Existing source code
- Traceability matrix

## Outputs

- Source code changes
- Test code or manual test hooks
- Traceability updates
- Build/test notes
- Implementation risk list

## Rules

- Do not implement behavior not present in approved design.
- Do not change public interfaces without change-control approval.
- Mention related design IDs in commits, PR descriptions, or implementation notes.
- For C/Linux driver/kernel work, check kernel API version, context constraints, locking, memory allocation context, error paths, module unload, and logging policy.
- For Rust, Java, and Python, check dependency versions, runtime assumptions, error handling, logging, and packaging/deployment assumptions.
- Prefer tests automated in CI when feasible.
- If hardware/equipment prevents automation, record the reason and evidence plan.
- Do not weaken tests to pass implementation.

## Required checks

- [ ] Detailed design ID linked
- [ ] Requirement/design/test IDs preserved
- [ ] Official API/document version checked
- [ ] Build target identified
- [ ] CI/manual/real-target test mode identified
- [ ] Error handling implemented as designed
- [ ] No requirement creep introduced
