# Linux Driver Design Skill

## Purpose

Create or review Linux kernel / device driver design artifacts while preserving V-model traceability and using version-matched official documentation.

## Scope

Use this skill for:

- Linux kernel module design
- Platform, PCI/PCIe, serial, char, net, block, or misc driver design
- IRQ, MSI/MSI-X, DMA, MMIO, sysfs, debugfs, ioctl, uevent, or RAS-related design
- Kernel-space/user-space boundary design
- Kernel version API impact checks

## Required inputs

- Approved requirement or basic design IDs
- Target Linux kernel version
- Target distribution/BSP, if applicable
- Target hardware or device specification
- Register map, if register access is required
- Interrupt specification, if IRQ/MSI/MSI-X is required
- DMA specification, if DMA is required
- Power management requirements, if suspend/resume is relevant
- RAS/log/diagnostic requirements, if applicable
- Version-matched official Linux kernel documentation references

## Outputs

- Driver design section or detailed design section
- Interface and lifecycle design
- Error handling and recovery design
- Test viewpoints for unit, integration, and system tests
- Official reference list
- TBD list
- Risk list
- Traceability mappings

## Design checklist

### Driver lifecycle

- Define probe/init path.
- Define remove/exit path.
- Define resource acquisition and release order.
- Define behavior for probe failure at each partial-initialization step.
- Define module unload behavior, if unload is supported.

### Device model

- Define bus type and binding method: PCI, platform, device tree, ACPI, USB, etc.
- Define device IDs and matching rules.
- Define device node exposure, if any.
- Define sysfs/debugfs/ioctl/netlink interfaces, if any.

### Register and MMIO access

- Identify register map source.
- Define mapping method.
- Define access width, endian assumptions, barriers, and ordering requirements.
- Define read-modify-write locking rules.
- Do not invent register definitions.

### Interrupts

- Define IRQ type and source.
- Define top-half and threaded/bottom-half responsibilities.
- Define shared IRQ behavior, if applicable.
- Define MSI/MSI-X vector allocation policy, if applicable.
- Define interrupt enable/disable and cleanup order.

### DMA

- Define streaming or coherent DMA model.
- Define buffer ownership and lifetime.
- Define mapping/unmapping rules.
- Define cache coherency assumptions.
- Define IOMMU constraints, if applicable.
- Define error handling for mapping failure.

### Concurrency and lifetime

- Identify shared data.
- Define locking primitives.
- Define IRQ/process context restrictions.
- Define sleepable and atomic contexts.
- Define reference count and lifetime ownership.
- Define race conditions during remove, suspend, reset, and error recovery.

### User-kernel boundary

- Define ABI stability expectations.
- Validate user input.
- Define copy_to_user/copy_from_user error handling, if used.
- Define ioctl compatibility considerations, if used.

### Logging and diagnostics

- Define log levels and rate limiting.
- Define dmesg-visible messages.
- Define RAS notification behavior, if applicable.
- Define debugfs/sysfs diagnostic exposure, if applicable.

### Power management

- Define suspend/resume behavior.
- Define runtime PM behavior, if applicable.
- Define interrupt/DMA quiesce and restore sequence.

### Version compatibility

- Check the target kernel version.
- Reference only version-matched official documentation or source code.
- Record API differences if supporting multiple versions.

## Prohibited behavior

- Do not invent hardware behavior.
- Do not invent register meanings.
- Do not assume DMA coherency without evidence.
- Do not assume IRQ context can sleep.
- Do not add a user-visible ABI without approved requirements.
- Do not claim a design is complete while mandatory hardware or kernel version information is missing.

## Gate handoff

After drafting the design, invoke or recommend `linux-driver-review` and `traceability-check` before moving to implementation.
