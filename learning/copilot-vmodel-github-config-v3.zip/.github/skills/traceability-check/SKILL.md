---
name: traceability-check
description: Use this skill to verify traceability across requirements, design, implementation, and tests.
---

# Traceability Check Skill

## Purpose

Verify that every development artifact is connected across the V-model.

## Required checks

- Every `REQ-` has at least one verification path.
- Every `BD-` traces to one or more `REQ-` IDs.
- Every `DD-` traces to one or more `BD-` and `REQ-` IDs.
- Every `IMPL-` traces to one or more `DD-` and `REQ-` IDs.
- Every `UT-` traces to `DD-` and `REQ-` IDs.
- Every `IT-` traces to `BD-` and `REQ-` IDs.
- Every `ST-` traces to `REQ-` IDs.
- No orphan implementation or orphan test exists.
- No requirement lacks a corresponding test strategy.

## Required output sections

1. Coverage summary
2. Orphan requirements
3. Orphan design items
4. Orphan implementation items
5. Orphan tests
6. Missing test levels
7. Suspected requirement/design drift
8. Required fixes
