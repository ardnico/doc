---
name: requirements
description: Use this skill to create, normalize, review, or index requirements for a V-model / waterfall project.
---

# Requirements Skill

## Purpose

Create or review requirements while preserving testability and traceability.

## Inputs

- Stakeholder request or input form
- Existing requirements specification
- Existing related specifications
- Constraints
- Glossary
- Target environment information
- Middleware / OS / toolchain information
- User manual or operational assumptions

## Outputs

- Requirements specification entries with `REQ-` IDs
- Acceptance criteria
- System test candidates with `ST-` IDs or placeholders
- Assumptions
- TBD list
- Risk list
- Traceability updates

## Rules

- Assign stable `REQ-` IDs to requirements that lack IDs.
- Preserve existing IDs when possible.
- Split compound requirements.
- Separate requirement, rationale, acceptance criteria, constraint, and assumption.
- Do not include implementation details unless they are explicit constraints.
- Mark untestable requirements as blocking issues.
- If mandatory input is missing, stop and request it.

## Required output sections

1. Requirements table
2. Acceptance criteria
3. Initial system test candidates
4. Missing inputs
5. Assumptions
6. TBDs
7. Traceability update proposal
8. Gate review result
