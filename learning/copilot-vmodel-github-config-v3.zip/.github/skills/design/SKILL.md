# Design Skill

## Purpose

Create or review basic and detailed design artifacts from approved requirements and approved previous-phase inputs.

## Inputs

- Approved requirements
- Existing design artifacts if any
- Environment conditions
- Middleware conditions
- Device/hardware specifications
- Operation/manual constraints
- Official version-matched documentation
- Redmine ticket imports when relevant

## Outputs

- Basic design specification or detailed design specification
- Design decisions
- Traceability updates
- Test design candidates
- TBD/blocker list

## Rules

- Do not add requirements during design.
- Every design item must reference source requirement IDs or approved constraints.
- Separate basic design concerns from detailed design concerns according to `.github/process/phase-map.yml`.
- For C/Linux driver/kernel work, explicitly check kernel version, target architecture, driver subsystem, locking, interrupt context, DMA/memory ownership, error handling, module lifecycle, and user/kernel boundary.
- For Java/Python/Rust applications, explicitly check runtime version, dependencies, error model, logging, configuration, and deployment environment.
- Use official documentation matched to the target version and record references.
- If official documentation is missing or version-mismatched, mark it as a blocker or risk.
- Preserve Redmine ticket source IDs when using ticket-derived inputs.

## Required checks

- [ ] Required input artifacts are approved or conditionally approved
- [ ] Official documentation version is recorded
- [ ] Environment and middleware assumptions are recorded
- [ ] Every design item is traceable
- [ ] No unapproved requirement was added
- [ ] Test design impact is identified
- [ ] TBDs and blockers are explicit
