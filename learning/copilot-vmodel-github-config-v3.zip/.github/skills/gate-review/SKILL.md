# Gate Review Skill

## Purpose

Determine whether a phase artifact is ready for human approval and whether the next phase can start.

## Inputs

- Current phase artifact
- Required previous-phase artifacts
- Artifact registry
- Approval policy
- Traceability matrix
- Phase checklist
- Review records
- Redmine imports when relevant
- Official reference records when relevant

## Outputs

- PASS recommendation / FAIL recommendation / CONDITIONAL PASS recommendation
- Blocking issues
- Non-blocking issues
- Required fixes
- Traceability gaps
- Missing input list
- Reusable review check candidates

## Rules

- Default to FAIL if required information is missing.
- Do not approve artifacts. Only recommend status.
- Do not pass artifacts with unresolved mandatory TBDs.
- Do not pass artifacts that introduce untraced requirements.
- Do not pass design/implementation artifacts without version-matched official reference checks when such references are required.
- Do not pass converted documents as approved unless a human review record exists.
- Extract reusable findings into `.github/review-knowledge/reusable-review-checks.md` candidates.

## Required checks

- [ ] Required inputs exist
- [ ] Required inputs are approved or conditionally approved
- [ ] Official references are version-matched when required
- [ ] Traceability complete
- [ ] Missing Redmine attachments checked when applicable
- [ ] Environment/middleware/manual conditions checked
- [ ] Review record exists or is prepared
- [ ] Reusable findings extracted
