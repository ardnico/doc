# Official Documentation Reference Skill

## Purpose

Use official, version-matched documentation as evidence for design, implementation, and review decisions.

## Inputs

- Current phase
- Target language/platform
- Target version information
- Existing project artifacts
- Requested design or implementation topic

## Outputs

- Official reference records
- Version applicability assessment
- Conflicts between official documentation and project artifacts
- Required follow-up questions or blockers

## Rules

- Prefer official documentation from the vendor, project, standards body, or maintained source repository.
- For Linux kernel work, match the target kernel version when possible.
- For WRLinux/Yocto/BSP work, match the target WRLinux/Yocto release and layer branch.
- For middleware, match the exact version used by the project.
- Do not rely on latest documentation if the project targets a different version.
- If version-matched documentation is unavailable, state the gap explicitly.
- Record references using `.github/templates/official-reference-template.md`.
- Do not copy large copyrighted excerpts. Summarize and cite location.

## Required checks

- [ ] Target version identified
- [ ] Official source identified
- [ ] Documentation version recorded
- [ ] Applicability assessed
- [ ] Conflicts recorded
- [ ] Referenced artifacts linked
