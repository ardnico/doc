# Test Design Skill

## Purpose

Create system, integration, and unit test specifications from the corresponding V-model input artifacts.

## Inputs

- Requirements for system test design
- Basic design for integration test design
- Detailed design for unit test design
- Environment conditions
- Middleware conditions
- Hardware/equipment constraints
- CI capabilities
- Official version-matched documentation when test behavior depends on platform/API behavior

## Outputs

- System test specification
- Integration test specification
- Unit test specification
- Test program candidates
- Manual test procedure when automation is not feasible
- Traceability updates

## Rules

- Every test case must trace to a requirement, design item, or approved constraint.
- Prefer automated tests.
- If not automated, record why.
- For hardware/equipment-dependent tests, record target, setup, equipment, safety constraints, operation procedure, expected result, and evidence.
- Do not create test expectations that exceed approved requirements/design.
- For kernel/driver tests, include module load/unload, error path, interrupt/DMA behavior when applicable, and recovery expectations.

## Required checks

- [ ] Test source artifact identified
- [ ] Test level identified: system / integration / unit
- [ ] Test mode identified: CI / host / emulator / real target / manual equipment
- [ ] Expected result defined
- [ ] Evidence to collect defined
- [ ] Traceability complete
- [ ] Non-automated reason recorded when applicable
