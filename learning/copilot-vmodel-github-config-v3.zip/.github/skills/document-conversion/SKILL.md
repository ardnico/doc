# Document Conversion Skill

## Purpose

Convert PDF, Word, Excel, Redmine extracts, and existing Markdown specifications into Markdown working artifacts that agents can index and review.

## Inputs

- Source document or extracted text
- Source metadata
- Target artifact type
- Conversion policy

## Outputs

- Converted Markdown
- Conversion report
- Candidate requirement/design/test items
- Ambiguity and loss report

## Rules

- Preserve source metadata.
- Preserve tables and headings as much as possible.
- Convert figures and screenshots into descriptions only when their meaning is clear.
- If a figure/table cannot be interpreted reliably, mark it as a conversion issue.
- Do not treat converted Markdown as approved.
- Generated IDs are provisional until artifact indexing and human review.
- Keep source references for every extracted item.

## Classification

Each extracted item must be classified as one of:

- requirement
- constraint
- design
- test expectation
- environment condition
- middleware condition
- manual/operation condition
- issue
- decision
- TBD
- reference

## Required checks

- [ ] Source metadata preserved
- [ ] Converted output path defined
- [ ] Conversion issues listed
- [ ] Candidate items classified
- [ ] Human review requirement stated
