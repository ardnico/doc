# Linux Driver Review Skill

## Purpose

Review Linux kernel / device driver artifacts for correctness, maintainability, V-model traceability, and kernel-version compatibility.

## Inputs

- Target artifact: requirement, design, code, or test specification
- Approved upstream artifacts
- Traceability matrix
- Target kernel version
- Official documentation references
- Hardware/device specification
- Applicable gate checklist

## Outputs

- PASS / FAIL / CONDITIONAL PASS recommendation
- Blocking issues
- Non-blocking issues
- Traceability gaps
- Required official-reference gaps
- Required rework
- Candidate reusable review checks

## Review areas

### Traceability

- Every driver behavior maps to REQ/BD/DD IDs.
- Every public interface maps to an approved requirement.
- Every test maps to requirement/design IDs.
- No untraced behavior exists.

### Kernel API and version

- API usage matches the target kernel version.
- Official documentation or kernel source references are version-matched.
- Compatibility assumptions are documented.

### Resource management

- Probe failure paths release all acquired resources.
- Remove path quiesces IRQ/DMA/workqueues/timers before releasing memory or registers.
- Devres/manual cleanup style is consistent.
- No use-after-free path is visible.

### IRQ and deferred work

- IRQ handler context is respected.
- Sleepable work is not performed in hard IRQ context.
- Disable/free order is safe.
- MSI/MSI-X vector assumptions are explicit.

### DMA

- Mapping/unmapping pairs are correct.
- Ownership transitions are clear.
- Coherency assumptions are documented.
- Error paths do not leak DMA mappings or buffers.

### Locking and concurrency

- Locking covers shared state.
- Atomic vs sleepable contexts are respected.
- Remove/suspend/reset races are considered.
- Lock order is documented where multiple locks exist.

### ABI and user interface

- sysfs/debugfs/ioctl behavior is documented.
- User input is validated.
- ABI changes have approved requirements.
- Debug-only interfaces are not mistaken for stable production ABI.

### Logging and RAS

- Logs are useful but not noisy.
- Repeated errors are rate-limited when needed.
- RAS notification paths are traceable to requirements.
- Error severity mapping is documented.

### Tests

- Unit tests, static checks, or review-only rationale exist for code paths that cannot be executed in CI.
- Hardware-dependent tests identify equipment, setup, expected results, and evidence.
- Module load/unload and error paths are tested or explicitly justified.

## Default stance

Default to FAIL when:

- Kernel version is unknown.
- Hardware behavior is assumed but not specified.
- Official references are missing for kernel API-sensitive design.
- Resource cleanup paths are incomplete.
- Traceability is missing.
- Tests are absent without justification.

## Reusable review checks

When a review finding is generic and likely to recur, propose adding it to:

- `.github/review-knowledge/reusable-review-checks.md`

Use this format:

```markdown
## CHK-XXXX: <short name>

- Applies to:
- Problem pattern:
- Check:
- Bad example:
- Required correction:
- Source review finding:
```
