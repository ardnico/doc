# Intake Routing Skill

## Purpose

Classify an incoming user request, check mandatory inputs, and choose the appropriate agent and skills before any engineering artifact is created or modified.

## Inputs

- User request
- `.github/process/intake-routing.yml`
- `.github/process/phase-map.yml`
- `.github/process/artifact-registry.yml`
- `.github/process/approval-policy.yml`
- Existing approved artifacts
- Redmine imports, if referenced
- Converted Markdown specifications, if referenced

## Outputs

- Intake result
- Required agent and skill selection
- Missing information list
- Blocking questions, if needed
- Next action

## Rules

- Do not draft requirements, design, code, or tests until intake classification is complete.
- Do not route implementation work unless an approved detailed design exists, unless the task is explicitly a spike or investigation.
- Do not route design work unless the required upstream requirements or source artifacts exist.
- Do not treat Redmine comments as approved requirements without review.
- Do not treat converted Markdown specifications as authoritative until reviewed.
- If a request spans multiple phases, split it and process the earliest upstream phase first.
- If a user asks a general question, answer it directly only when it does not modify project artifacts or imply phase progression.

## Classification procedure

1. Extract requested action.
2. Extract mentioned artifacts, IDs, files, tickets, versions, and target components.
3. Determine whether the request is creation, modification, review, conversion, import, or investigation.
4. Match the request to `.github/process/intake-routing.yml`.
5. Determine required inputs.
6. Check approval status in artifact registry or review records.
7. Check whether official version-matched references are required.
8. Check whether Redmine or converted documents are involved.
9. Select target agent and skills.
10. Proceed or ask blocking questions.

## Output template

```markdown
## Intake result

- Request class:
- Current phase:
- Target agent:
- Skills:
- Required inputs:
- Available inputs:
- Missing blocking inputs:
- Missing non-blocking inputs:
- Official references required:
- Redmine inputs required:
- Proceed / Stop:

## Blocking questions

1.

## Next action
```

## Question policy

Ask questions only when the answer blocks correct routing or safe execution.

Bad question:

- "How would you like this to be structured?"

Better question:

- "Which approved requirements document should be treated as the source for this basic design?"
- "What Linux kernel version is the target for this driver design?"
- "Is Redmine ticket #1234 already reviewed as an approved input, or should it be imported as raw source information?"
