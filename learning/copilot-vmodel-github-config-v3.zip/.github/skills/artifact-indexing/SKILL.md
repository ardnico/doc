# Artifact Indexing Skill

## Purpose

Read existing specifications, converted Markdown, Redmine ticket imports, and source artifacts; assign stable IDs; and build an index for traceability.

## Inputs

- Existing Markdown specifications
- Converted Markdown from PDF/Word/Excel
- Redmine ticket imports
- Existing source code
- Existing test cases
- Artifact registry

## Outputs

- Indexed artifact list
- Assigned or normalized IDs
- Traceability candidates
- Ambiguous item list
- Human review list

## ID prefixes

- REQ: requirement
- BD: basic design
- DD: detailed design
- IMPL: implementation item
- UT: unit test
- IT: integration test
- ST: system test
- ENV: environment condition
- MID: middleware condition
- MAN: manual/operation condition
- REF: official reference
- RM: Redmine source item
- CR: change request
- TBD: unresolved item
- RISK: risk
- DR: design review finding
- CHK: reusable review check

## Rules

- Preserve original IDs when they already exist.
- Do not overwrite existing stable IDs without explicit approval.
- Generated IDs from converted documents are provisional until reviewed.
- Separate explicit statements from inferred items.
- Separate current content from stale or obsolete content.
- Preserve source location for each indexed item.
- Do not treat Redmine discussion comments as requirements unless reviewed.

## Required checks

- [ ] Source document identified
- [ ] Source version/status recorded
- [ ] IDs assigned or preserved
- [ ] Provisional IDs marked
- [ ] Inferred items separated
- [ ] Ambiguities listed
- [ ] Human review required where needed
