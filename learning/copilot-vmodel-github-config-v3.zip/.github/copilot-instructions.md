# Repository-wide Copilot Instructions

This repository uses a strict V-model / waterfall-style process.

## Core rules

- Follow `.github/process/phase-map.yml` for phase inputs and outputs.
- Use approved previous-phase artifacts as authoritative inputs.
- Do not proceed when mandatory inputs are missing.
- Preserve traceability between requirements, design, implementation, and tests.
- Separate facts, assumptions, TBDs, risks, and decisions.
- Do not add requirements during design or implementation.
- Do not infer missing specifications silently.
- If a conflict exists, report it instead of resolving it implicitly.
- Human review records determine approval status.

## Target scope

Primary target:

- C
- Linux device drivers
- Linux kernel-related source
- BSP/platform code
- low-level middleware integration

Additional supported targets:

- Java applications
- Python tools/scripts
- Rust tools/applications

Language-specific rules are secondary to process, traceability, and approval rules.

## Official documentation requirement

For design, implementation, and review, consult official documentation that matches the target version.
Record the documentation version and applicability. Do not rely on unrelated latest-version documentation when the project targets a specific older version.

## External inputs

Redmine ticket extracts, PDF, Word, and Excel documents may be used as inputs only after they are imported or converted into Markdown and indexed. Converted Markdown is a working artifact until reviewed and approved.

## Testing policy

Both CI-based automated testing and hardware/equipment-dependent testing are supported.
When automation is not possible, record the reason, test environment, manual procedure, expected result, and evidence to be collected.

## Intake first

Before creating or modifying requirements, design, source code, tests, or review records, classify the request using the intake routing rules in `.github/process/intake-routing.yml`.

If mandatory inputs are missing, ask only the blocking questions. Do not fabricate requirements, approvals, official references, kernel versions, hardware behavior, or test results.

## Linux driver / kernel rule

For Linux driver or kernel-related work, apply `.github/skills/linux-driver-design/SKILL.md`, `.github/skills/linux-driver-review/SKILL.md`, and `.github/process/checklists/linux-driver-design-gate.md` as applicable.

