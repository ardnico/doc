# Basic Design Gate Checklist

Judgment defaults to FAIL if any mandatory item is missing.

## Inputs

- [ ] Approved requirements specification exists.
- [ ] All referenced `REQ-` IDs exist.
- [ ] Required environment, middleware, external interface, and operational documents are available or listed as blocking gaps.

## Design quality

- [ ] Every basic design item has a stable `BD-` ID.
- [ ] Every `BD-` item traces to one or more `REQ-` IDs.
- [ ] All `REQ-` items are covered or explicitly marked not applicable with rationale.
- [ ] External interfaces are defined.
- [ ] Data flow, state transition, and error handling are defined at architecture level.
- [ ] Non-functional requirements have design responses.
- [ ] No unapproved requirement is introduced.
- [ ] Design decisions are recorded with rationale.

## Test counterpart

- [ ] Integration test candidates or integration test specification links exist for every relevant `BD-` item.

## Traceability

- [ ] Traceability matrix links `REQ-` to `BD-` and `IT-` candidates.
