# Test Design Gate Checklist

- [ ] Test level is identified: system / integration / unit
- [ ] Correct source artifact is used
- [ ] Every test case has a traceability source ID
- [ ] Expected results are explicit
- [ ] Test environment is explicit
- [ ] CI/manual/real-target/equipment-dependent mode is identified
- [ ] Non-automated tests include reason and evidence plan
- [ ] Hardware/equipment safety constraints are recorded when applicable
- [ ] Official behavior references are version-matched when applicable
- [ ] No test expectation exceeds approved requirements/design
- [ ] Review record exists
