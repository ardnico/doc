# Detailed Design Gate Checklist

Judgment defaults to FAIL if any mandatory item is missing.

## Inputs

- [ ] Approved basic design specification exists.
- [ ] All referenced `BD-` IDs exist.
- [ ] Build, runtime, middleware, and toolchain assumptions are confirmed.

## Design quality

- [ ] Every detailed design item has a stable `DD-` ID.
- [ ] Every `DD-` item traces to one or more `BD-` and `REQ-` IDs.
- [ ] Module, function, data structure, and interface responsibilities are defined.
- [ ] Error handling and recovery behavior are defined.
- [ ] Logging, diagnostics, and observability behavior are defined.
- [ ] Resource ownership and lifecycle are defined.
- [ ] Timing, concurrency, locking, and interrupt/context constraints are defined where applicable.
- [ ] Implementation can start without additional design judgment.
- [ ] No unapproved requirement or basic design change is introduced.

## Test counterpart

- [ ] Unit test specification or unit test candidates exist for every relevant `DD-` item.

## Traceability

- [ ] Traceability matrix links `REQ-`, `BD-`, `DD-`, and `UT-` candidates.
