# Implementation Gate Checklist

- [ ] Approved detailed design exists
- [ ] Approved or conditionally approved test design exists
- [ ] Implementation references detailed design IDs
- [ ] Source changes do not introduce unapproved requirements
- [ ] Official API/document version was checked where relevant
- [ ] Target language/runtime/toolchain version is recorded
- [ ] Build environment is recorded
- [ ] CI tests are run when available
- [ ] Hardware/equipment-dependent tests are planned when CI is insufficient
- [ ] Error handling follows design
- [ ] Logging/diagnostics follow design
- [ ] Public interface changes have change-control approval
- [ ] Traceability matrix is updated
- [ ] Review record exists
