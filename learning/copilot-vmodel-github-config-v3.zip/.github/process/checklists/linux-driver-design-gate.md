# Linux Driver Design Gate Checklist

Use this checklist before approving Linux kernel / driver design artifacts.

## Source and traceability

- [ ] Approved upstream requirement or design IDs are listed.
- [ ] Target Linux kernel version is listed.
- [ ] Target distribution/BSP is listed, if applicable.
- [ ] Hardware/device specification source is listed.
- [ ] Register map source is listed, if register access exists.
- [ ] Interrupt specification source is listed, if IRQ/MSI/MSI-X exists.
- [ ] DMA specification source is listed, if DMA exists.
- [ ] Official documentation references are version-matched.
- [ ] All design items have traceability IDs.

## Lifecycle

- [ ] probe/init flow is defined.
- [ ] remove/exit flow is defined.
- [ ] Partial initialization failure cleanup is defined.
- [ ] Module unload behavior is defined or explicitly unsupported.

## Hardware access

- [ ] MMIO/register access rules are defined.
- [ ] Access width/endian/order assumptions are defined.
- [ ] Register read-modify-write protection is defined.

## Interrupts and deferred processing

- [ ] IRQ type and allocation policy are defined.
- [ ] Top-half and bottom-half responsibilities are separated.
- [ ] Sleepable work is not assigned to hard IRQ context.
- [ ] Interrupt cleanup order is defined.

## DMA

- [ ] DMA model is defined.
- [ ] Buffer ownership is defined.
- [ ] Mapping/unmapping rules are defined.
- [ ] Coherency assumptions are documented.
- [ ] DMA failure handling is defined.

## Concurrency

- [ ] Shared state is identified.
- [ ] Locking rules are defined.
- [ ] Atomic/sleepable context restrictions are defined.
- [ ] Remove/suspend/reset races are considered.

## User interface and ABI

- [ ] sysfs/debugfs/ioctl/user-visible interfaces are defined, if any.
- [ ] ABI stability expectations are defined.
- [ ] User input validation policy is defined.

## Diagnostics and RAS

- [ ] Log levels and rate limiting policy are defined.
- [ ] RAS notification behavior is defined, if applicable.
- [ ] Diagnostic information exposure is defined.

## Tests

- [ ] Unit test viewpoints are listed.
- [ ] Integration test viewpoints are listed.
- [ ] System/hardware test viewpoints are listed.
- [ ] CI-executable tests are separated from equipment-dependent tests.
- [ ] Manual test evidence requirements are defined.

## Gate result

- [ ] PASS
- [ ] CONDITIONAL PASS with approved residual issues
- [ ] FAIL
