# Requirements Gate Checklist

Judgment defaults to FAIL if any mandatory item is missing.

## Inputs

- [ ] Input format / stakeholder request exists.
- [ ] Source of each request is identified.
- [ ] Existing related specifications have been checked.
- [ ] Target environment assumptions are listed or marked missing.
- [ ] Middleware / OS / toolchain assumptions are listed or marked missing.
- [ ] User manual / operational assumptions are listed or marked missing.

## Requirements quality

- [ ] Every requirement has a stable `REQ-` ID.
- [ ] Every requirement is testable.
- [ ] Acceptance criteria exist for every requirement.
- [ ] Functional requirements, non-functional requirements, constraints, and assumptions are separated.
- [ ] Ambiguous words are either defined or removed.
- [ ] TBD items are listed with owner and blocking/non-blocking status.
- [ ] Requirements do not contain unnecessary implementation details.

## Test counterpart

- [ ] System test candidates or system test specification links exist for every `REQ-` item.
- [ ] Requirements with no test path are marked as blocking issues.

## Traceability

- [ ] Traceability matrix includes all `REQ-` items.
- [ ] Each requirement links to source input or rationale.
